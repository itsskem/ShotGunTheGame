public class Computer {  //this is programming the CPU
    private String shoot;
    private String reload;
    private String reflect;
    private String block;

    public Computer(String theShoot, String theReload, String theReflect, String theBlock){
        shoot = theShoot;
        reload = theReload;
        reflect = theReflect;
        block = theBlock;
    }

    public String getShoot(){  //when the user says shoot, the cpu will return reload. this move causes wins to go up by one.
        return reload;
    }

    public String getReload(){  //when the user reloads, the cpu will return shoot. this move causes huts to go up by one
        return shoot;
    }

    public String getReflect(){ //when the user reflects, the cpu will block.

        return block;
    }

    public String getBlock() {  //when the user blocks, the cpu will reflect
        return reflect;
    }
}
