import java.util.Scanner;
public class Main {

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Please enter your name: ");
        String userName = input.nextLine(); // user enters their name for a more personal experience

        Computer CPU = new Computer("CPU says reload", "CPU says block", "CPU says shoot", "CPU says reflect"); //setting up the CPU
        LevelOne player = new LevelOne(userName, CPU); //creating the player object and infusing the CPU

        System.out.println(player);

        //just explaining the rules
        System.out.println("This is the computer version of the hand game. You have four moves.");
        System.out.println("Shoot blasts the opponent, Reload is to reload your blaster, Block is to shield yourself, and Reflect is to use the mirror.");
        System.out.println("You will not be able to see what the computer is doing. Just know that it is responding to your moves.");
        System.out.println("Just try your best :). Good luck");

        int wins = 0; //initializes number of wins to 0
        int hits = 0; //initializes  number of hits to 0


        System.out.println("Disclaimer: You start off with one ammo only. Once you use it, you need to reload in order to shoot.");
        int ammo = 1; //initializes number of ammo to 1

        System.out.println("How many rounds would you like to play");//user enters how many rounds they want to play
        int numOfRounds = input.nextInt();




        for (int i = 0; i <= numOfRounds; i++) {    //used to count for each round. method is called for every move the user enters

            System.out.println("Make your move: ");
            String move = input.nextLine();


            if (move.equals("shoot")) {   //when the user says shoot
                ammo--;
                CPU.getShoot();
                wins++;
                if (ammo == 0){    //if user runs out of ammo
                    System.out.println("Need to reload!");
                } else {
                }
            } else if (move.equals("reflect")) {  //when the user says reflect
                CPU.getReflect();
                hits++;
            } else if (move.equals("block")) {  //when the user says block
                CPU.getBlock();
            } else if (move.equals("reload")) {  //when the user says reload
                    CPU.getReload();
                    ammo++;
            } else {
                System.out.println("That is not an available move! Don't worry. Adding another round so you can try again"); //if the user makes a mistake, it will simply add another round so they can try again
                numOfRounds++;
            }
        }
        System.out.println("Number of wins: " + wins); //calculates the number of wins.
        System.out.println("Number of hits: " + hits); //calculates the number of wins
        System.out.println("Amount of ammo left: " + ammo); //calculates remaining ammo

        if (wins > hits){
            System.out.println("You win!");
        } else if (wins == hits) {
            System.out.println("It is a tie.");
        } else {
            System.out.println("CPU wins!");
        }
        }

    }



