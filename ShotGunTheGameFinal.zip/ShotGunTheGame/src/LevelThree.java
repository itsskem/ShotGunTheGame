public class LevelThree {
    private Computer3 move;  //initializing the cpu
    private String username;  //users name
    private String shoot3;     //the moves the can make
    private String reload3;
    private String reflect3;
    private String block3;


    public LevelThree(String UserName, Computer3 computerMove){ //setting up the constructor
        username = UserName;
        move = computerMove;

    }

    public String getName(){  //gets the Users' name

        return username;
    }

    public String userSaysShoot3(){ //when the user says "shoot", this method will run from the computer class.

        return move.getShoot3();
    }

    public String userSaysReflect3(){
        return move.getReflect3();
    } //when the user says "reflect", this method will run from the computer class.

    public String userSaysBlock3(){
        return move.getBlock3();
    } //when the user says "block", this method will run from the computer class.

    public String userSaysReload3(){
        return move.getReload3();
    } //when the user says "reload", this method will run from the computer class.

    public String toString(){

        return "Welcome, " + username + ". Lets play Shotgun. You are playing on level three.";
    }
}
