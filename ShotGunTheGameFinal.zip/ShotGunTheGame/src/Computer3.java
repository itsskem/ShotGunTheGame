public class Computer3 {
    private String shoot3;
    private String reload3;
    private String reflect3;
    private String block3;

    public Computer3(String theShoot, String theReload, String theReflect, String theBlock){
        shoot3 = theShoot;
        reload3 = theReload;
        reflect3 = theReflect;
        block3 = theBlock;
    }

    public String getShoot3(){  //when the user says shoot, the cpu will return shoot. this move causes wins to go up by one.
        return shoot3;
    }

    public String getReload3(){  //when the user reloads, the cpu will return shoot. this move causes huts to go up by one
        return shoot3;
    }

    public String getReflect3(){ //when the user reflects, the cpu will block.

        return reload3;
    }

    public String getBlock3() {  //when the user blocks, the cpu will reflect

        return block3;
    }
}
