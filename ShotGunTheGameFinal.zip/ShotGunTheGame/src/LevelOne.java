public class LevelOne {
//the plan is to have levels. so far this is "level one"
    private Computer move;  //initializing the cpu
    private String username;  //users name
    private String shoot;     //the moves the can make
    private String reload;
    private String reflect;
    private String block;


    public LevelOne(String UserName, Computer computerMove){ //setting up the constructor
        username = UserName;
        move = computerMove;

    }

    public String getName(){  //gets the Users' name

        return username;
    }

    public String userSaysShoot(){ //when the user says "shoot", this method will run from the computer class.

        return move.getShoot();
    }

    public String userSaysReflect(){
        return move.getReflect();
    } //when the user says "reflect", this method will run from the computer class.

    public String userSaysBlock(){
        return move.getBlock();
    } //when the user says "block", this method will run from the computer class.

    public String userSaysReload(){
        return move.getReload();
    } //when the user says "reload", this method will run from the computer class.

    public String toString(){

        return "Welcome, " + username + ". Lets play Shotgun. You are playing on level one.";
    }


}
