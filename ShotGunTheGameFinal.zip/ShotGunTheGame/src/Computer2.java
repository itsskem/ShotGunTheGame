public class Computer2 {
    //this is for level 2
    private String shoot2;
    private String reload2;
    private String reflect2;
    private String block2;

    public Computer2(String theShoot, String theReload, String theReflect, String theBlock){
        shoot2 = theShoot;
        reload2 = theReload;
        reflect2 = theReflect;
        block2 = theBlock;
    }

    public String getShoot2(){  //when the user says shoot, the cpu will return shoot. this move causes wins to go up by one.
        return shoot2;
    }

    public String getReload2(){  //when the user reloads, the cpu will return shoot. this move causes huts to go up by one
        return block2;
    }

    public String getReflect2(){ //when the user reflects, the cpu will block.

        return reload2;
    }

    public String getBlock2() {  //when the user blocks, the cpu will reflect

        return reflect2;
    }
}
