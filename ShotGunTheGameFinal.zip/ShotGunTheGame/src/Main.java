import java.util.Scanner;
public class Main {
    //new feature = become invisible

    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        System.out.println("Please enter your name: ");
        String userName = input.nextLine(); // user enters their name for a more personal experience

        System.out.println("Would you like to play?");
        String answer = input.nextLine();

        if (answer.equals("yes")) {


            System.out.println("What level would you like to play at? 1 is easy, 2 is medium, and 3 is hard.");
            int chosenLevel = input.nextInt();

            if (chosenLevel == 1) {
                Computer CPU = new Computer("CPU says reload", "CPU says block", "CPU says shoot", "CPU says reflect"); //setting up the CPU
                LevelOne player = new LevelOne(userName, CPU); //creating the player object and infusing the CPU

                System.out.println(player);

                //just explaining the rules
                System.out.println("This is the computer version of the hand game. You have four moves.");
                System.out.println("Shoot blasts the opponent, Reload is to reload your blaster, Block is to shield yourself, and Reflect is to use the mirror.");


                int wins = 0; //initializes number of wins to 0
                int hits = 0; //initializes  number of hits to 0


                System.out.println("Disclaimer: You start off with one ammo only. Once you use it, you need to reload in order to shoot.");
                System.out.println("The first move is just a tester. That means the code is working :)");
                int ammo = 1; //initializes number of ammo to 1


                System.out.println("How many rounds would you like to play this round");//user enters how many rounds they want to play
                int numOfRounds = input.nextInt();


                for (int i = 0; i <= numOfRounds; i++) {    //used to count for each round. method is called for every move the user enters

                    System.out.println("Make your move: ");
                    String move = input.nextLine();


                    if (move.equals("shoot")) {   //when the user says shoot
                        ammo--;
                        CPU.getShoot();
                        System.out.println("CPU says reload");
                        wins++;
                        if (ammo <= 0) {    //if user runs out of ammo
                            System.out.println("Reload your blaster.!");
                        } else {
                        }
                    } else if (move.equals("reflect")) {  //when the user says reflect
                        CPU.getReflect();
                        System.out.println("CPU says block");
                        hits++;
                    } else if (move.equals("block")) {  //when the user says block
                        CPU.getBlock();
                        System.out.println("CPU says reflect");
                    } else if (move.equals("reload")) {  //when the user says reload
                        CPU.getReload();
                        System.out.println("CPU says shoot");
                        ammo++;
                    } else {
                        System.out.println("That is not an available move! Don't worry. Adding another round so you can try again"); //if the user makes a mistake, it will simply add another round so they can try again
                        // numOfRounds++;
                    }
                }

                if (wins > hits) {
                    System.out.println("You win!");
                } else if (wins == hits) {
                    System.out.println("It is a tie.");
                } else {
                    System.out.println("CPU wins!");
                }
            } else if (chosenLevel == 2) {
                Computer2 CPU2 = new Computer2("CPU says shoot", "CPU says block", "CPU says reload", "CPU says reflect");
                LevelTwo player2 = new LevelTwo(userName, CPU2);

                System.out.println(player2);

                //just explaining the rules
                System.out.println("This is the computer version of the hand game. You have four moves.");
                System.out.println("Shoot blasts the opponent, Reload is to reload your blaster, Block is to shield yourself, and Reflect is to use the mirror.");


                int wins = 0; //initializes number of wins to 0
                int hits = 0; //initializes  number of hits to 0


                System.out.println("Disclaimer: You start off with one ammo only. Once you use it, you need to reload in order to shoot.");
                int ammo = 1; //initializes number of ammo to 1

                System.out.println("How many rounds would you like to play");//user enters how many rounds they want to play
                int numOfRounds = input.nextInt();


                for (int i = 0; i <= numOfRounds; i++) {    //used to count for each round. method is called for every move the user enters

                    System.out.println("Make your move: ");
                    String move = input.nextLine();


                    if (move.equals("shoot")) {   //when the user says shoot
                        ammo--;
                        CPU2.getShoot2();
                        System.out.println("CPU says shoot");
                        wins++;
                        hits++;
                        if (ammo <= 0) {    //if user runs out of ammo
                            System.out.println("Reload your blaster.!");
                        } else {
                        }
                    } else if (move.equals("reflect")) {  //when the user says reflect
                        CPU2.getReflect2();
                        System.out.println("CPU says reload");

                    } else if (move.equals("block")) {  //when the user says block
                        CPU2.getBlock2();
                        System.out.println("CPU says reflect");
                    } else if (move.equals("reload")) {  //when the user says reload
                        CPU2.getReload2();
                        System.out.println("CPU says block");
                        ammo++;
                    } else {
                        System.out.println("That is not an available move! Don't worry. Adding another round so you can try again"); //if the user makes a mistake, it will simply add another round so they can try again
                        // numOfRounds++;
                    }
                }

            } else if (chosenLevel == 3) {
                Computer3 CPU3 = new Computer3("CPU says shoot", "CPU says shoot", "CPU says reload", "CPU says block");
                LevelThree player3 = new LevelThree(userName, CPU3);

                System.out.println(player3);

                //just explaining the rules
                System.out.println("This is the computer version of the hand game. You have four moves.");
                System.out.println("Shoot blasts the opponent, Reload is to reload your blaster, Block is to shield yourself, and Reflect is to use the mirror.");


                int wins = 0; //initializes number of wins to 0
                int hits = 0; //initializes  number of hits to 0


                System.out.println("Disclaimer: You start off with one ammo only. Once you use it, you need to reload in order to shoot.");
                int ammo = 1; //initializes number of ammo to 1

                System.out.println("How many rounds would you like to play");//user enters how many rounds they want to play
                int numOfRounds = input.nextInt();


                for (int i = 0; i <= numOfRounds; i++) {    //used to count for each round. method is called for every move the user enters

                    System.out.println("Make your move: ");
                    String move = input.nextLine();


                    if (move.equals("shoot")) {   //when the user says shoot
                        ammo--;
                        CPU3.getShoot3();
                        System.out.println("CPU says shoot");
                        wins++;
                        hits++;
                        if (ammo <= 0) {    //if user runs out of ammo
                            System.out.println("Reload your blaster.!");
                        } else {
                        }
                    } else if (move.equals("reflect")) {  //when the user says reflect
                        CPU3.getReflect3();
                        System.out.println("CPU says reload");
                        hits++;
                    } else if (move.equals("block")) {  //when the user says block
                        CPU3.getBlock3();
                        System.out.println("CPU says block");
                    } else if (move.equals("reload")) {  //when the user says reload
                        CPU3.getReload3();
                        System.out.println("CPU says shoot");
                        ammo++;
                        hits++;
                    } else {
                        System.out.println("That is not an available move! Don't worry. Adding another round so you can try again"); //if the user makes a mistake, it will simply add another round so they can try again
                        // numOfRounds++;
                    }
                }


            } else {

            }

        }

    }
}



