public class LevelTwo {
    //this is level 2
    private Computer2 move;  //initializing the cpu
    private String username;  //users name
    private String shoot2;     //the moves the can make
    private String reload2;
    private String reflect2;
    private String block2;


    public LevelTwo(String UserName, Computer2 computerMove){ //setting up the constructor
        username = UserName;
        move = computerMove;

    }

    public String getName(){  //gets the Users' name

        return username;
    }

    public String userSaysShoot2(){ //when the user says "shoot", this method will run from the computer class.

        return move.getShoot2();
    }

    public String userSaysReflect2(){
        return move.getReflect2();
    } //when the user says "reflect", this method will run from the computer class.

    public String userSaysBlock2(){
        return move.getBlock2();
    } //when the user says "block", this method will run from the computer class.

    public String userSaysReload2(){
        return move.getReload2();
    } //when the user says "reload", this method will run from the computer class.

    public String toString(){

        return "Welcome, " + username + ". Lets play Shotgun. You are playing on level two.";
    }


}
